# Crate Name

## Design

TODO: This section should have a high-level design of the crate.

Some questions that might help in writing this section:
- What is the purpose of this crate?
- What are the main components of the crate? How do they interact which each
  other?

## Usage

TODO: This section describes how the crate is used.

Some questions that might help in writing this section:
- What traits do users need to implement?
- Does the crate have any default/optional features? What is each feature
  doing?
- Is this crate used by other rust-vmm components? If yes, how?

## Examples

TODO: Usage examples.

```rust
use my_crate;

...
```

## License

**!!!NOTICE**: The BSD-3-Clause license is not included in this template.
The license needs to be manually added because the text of the license file
also includes the copyright. The copyright can be different for different
crates. If the crate contains code from CrosVM, the crate must add the
CrosVM copyright which can be found
[here](https://chromium.googlesource.com/chromiumos/platform/crosvm/+/master/LICENSE).
For crates developed from scratch, the copyright is different and depends on
the contributors.
